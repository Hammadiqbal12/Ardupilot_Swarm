# Copyright 2023 ArduPilot.org.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.

# Adapted from https://github.com/gazebosim/ros_gz_project_template
#
# Copyright 2019 Open Source Robotics Foundation, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Launch an iris quadcopter in Gazebo and Rviz."""
from pathlib import Path

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    """Generate a launch description for a iris quadcopter."""
    pkg_project_bringup = get_package_share_directory("ardupilot_gz_bringup")
    pkg_project_gazebo = get_package_share_directory("ardupilot_gz_gazebo")
    pkg_ros_gz_sim = get_package_share_directory("ros_gz_sim")

    # Iris.
    iris = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            [
                PathJoinSubstitution(
                    [
                        FindPackageShare("ardupilot_gz_bringup"),
                        "launch",
                        "robots",
                        "iris_lidar_multi.launch.py",
                    ]
                ),
            ]
        ),
        launch_arguments={
            "num_vehicles": LaunchConfiguration("num_vehicles"),
            "vehicle_prefix": LaunchConfiguration("vehicle_prefix"),
            "start_index": LaunchConfiguration("start_index"),
            "start_x": LaunchConfiguration("start_x"),
            "x_spacing": LaunchConfiguration("x_spacing"),
            "y": LaunchConfiguration("y"),
            "z": LaunchConfiguration("z"),
            "R": LaunchConfiguration("R"),
            "P": LaunchConfiguration("P"),
            "Y": LaunchConfiguration("Y"),
            "lidar_dim": LaunchConfiguration("lidar_dim"),
            "use_gz_tf": LaunchConfiguration("use_gz_tf"),
        }.items(),
    )

    tf_tree = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            [
                PathJoinSubstitution(
                    [
                        FindPackageShare("misc_nodes"),
                        "launch",
                        "tf_tree.launch.py",
                    ]
                ),
            ]
        ),
        launch_arguments={
            "num_vehicles": LaunchConfiguration("num_vehicles"),
            "vehicle_prefix": LaunchConfiguration("vehicle_prefix"),
            "start_index": LaunchConfiguration("start_index"),
            "map_frame": LaunchConfiguration("map_frame"),
        }.items(),
    )

    # Gazebo.
    gz_sim_server = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            f'{Path(pkg_ros_gz_sim) / "launch" / "gz_sim.launch.py"}'
        ),
        launch_arguments={
            "gz_args": "-v4 -s -r "
            + f'{Path(pkg_project_gazebo) / "worlds" / "iris_forest.sdf"}'
        }.items(),
    )

    gz_sim_gui = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            f'{Path(pkg_ros_gz_sim) / "launch" / "gz_sim.launch.py"}'
        ),
        launch_arguments={"gz_args": "-v4 -g"}.items(),
    )

    # RViz.
    rviz = Node(
        package="rviz2",
        executable="rviz2",
        arguments=[
            "-d",
            f'{Path(pkg_project_bringup) / "rviz" / "iris_with_lidar.rviz"}',
        ],
        condition=IfCondition(LaunchConfiguration("rviz")),
    )

    return LaunchDescription(
        [
            DeclareLaunchArgument(
                "rviz", default_value="true", description="Open RViz."
            ),
            DeclareLaunchArgument(
                "lidar_dim",
                default_value="3",
                description="Whether to use a 2D or 3D lidar",
            ),
            DeclareLaunchArgument(
                "num_vehicles",
                default_value="2",
                description="Number of iris vehicles to spawn.",
            ),
            DeclareLaunchArgument(
                "vehicle_prefix",
                default_value="iris",
                description="Namespace prefix (vehicles named prefix + index).",
            ),
            DeclareLaunchArgument(
                "start_index",
                default_value="1",
                description="Numeric suffix for the first vehicle.",
            ),
            DeclareLaunchArgument(
                "start_x",
                default_value="0.0",
                description="Initial X coordinate for the first vehicle (m).",
            ),
            DeclareLaunchArgument(
                "x_spacing",
                default_value="1.0",
                description="Spacing applied along +X between vehicles (m).",
            ),
            DeclareLaunchArgument("y", default_value="0.0", description="Y position (m)."),
            DeclareLaunchArgument(
                "z",
                default_value="0.194923",
                description="Z position (m).",
            ),
            DeclareLaunchArgument("R", default_value="0.0", description="Roll (rad)."),
            DeclareLaunchArgument("P", default_value="0.0", description="Pitch (rad)."),
            DeclareLaunchArgument("Y", default_value="0.0", description="Yaw (rad)."),
            DeclareLaunchArgument(
                "use_gz_tf",
                default_value="true",
                description="Relay Gazebo TF frames to ROS namespaces.",
            ),
            DeclareLaunchArgument(
                "map_frame",
                default_value="map",
                description="Global frame published by tf_tree.",
            ),
            gz_sim_server,
            gz_sim_gui,
            iris,
            tf_tree,
            rviz,
        ]
    )
