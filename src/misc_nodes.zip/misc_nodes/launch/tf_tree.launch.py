from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    # tf_odom for iris (listens on /iris/odometry)
    tf_odom_iris = Node(
        package='misc_nodes',
        executable='tf_odom',
        name='tf_odom_iris',
        namespace='iris',
        # Using absolute topic remap to be explicit
        remappings=[('odometry', '/iris/odometry')],
        # Optional: frames as params if your node supports it
        parameters=[{'odom_frame': 'iris/odom', 'base_frame': 'iris/base_link'}],
        output='screen'
    )

    # tf_odom for iris2 (listens on /iris2/odometry)
    tf_odom_iris2 = Node(
        package='misc_nodes',
        executable='tf_odom',
        name='tf_odom_iris2',
        namespace='iris2',
        remappings=[('odometry', '/iris2/odometry')],
        parameters=[{'odom_frame': 'iris2/odom', 'base_frame': 'iris2/base_link'}],
        output='screen'
    )

    # Static transforms (identity) requested:
    # map -> iris/odom
    static_map_to_iris_odom = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='static_map_to_iris_odom',
        arguments=['0', '0', '0', '0', '0', '0', 'map', 'iris/odom'],
        output='screen'
    )

    # map -> iris2/odom
    static_map_to_iris2_odom = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='static_map_to_iris2_odom',
        arguments=['0', '0', '0', '0', '0', '0', 'map', 'iris2/odom'],
        output='screen'
    )

    return LaunchDescription([
        tf_odom_iris,
        tf_odom_iris2,
        static_map_to_iris_odom,
        static_map_to_iris2_odom,
    ])

